import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

# 1. LOAD THE DATASET
try:
    df = pd.read_csv('loan_prediction_dataset.csv')
except FileNotFoundError:
    # Creating a mock dataframe to ensure the script runs standalone if file isn't present
    np.random.seed(42)
    n = 300
    df = pd.DataFrame({
        'Gender': np.random.choice(['Male', 'Female'], n),
        'Married': np.random.choice(['Yes', 'No'], n),
        'Education': np.random.choice(['Graduate', 'Not Graduate'], n),
        'Self_Employed': np.random.choice(['Yes', 'No', np.nan], n, p=[0.1, 0.8, 0.1]),
        'ApplicantIncome': np.random.randint(2000, 10000, n),
        'CoapplicantIncome': np.random.randint(0, 5000, n),
        'LoanAmount': np.random.choice([np.nan, 100, 150, 200, 250], n, p=[0.05, 0.3, 0.3, 0.2, 0.15]),
        'Credit_History': np.random.choice([1.0, 0.0, np.nan], n, p=[0.7, 0.2, 0.1]),
        'Property_Area': np.random.choice(['Urban', 'Semiurban', 'Rural'], n),
        'Loan_Status': np.random.choice(['Y', 'N'], n, p=[0.7, 0.3])
    })

print("** Initial Dataset Shape **")
print(df.shape)

# 2. HANDLE MISSING DATA (Data Cleaning)
# Categorical columns: Impute with Mode
categorical_cols = ['Gender', 'Married', 'Self_Employed', 'Credit_History']
for col in categorical_cols:
    if col in df.columns:
        df[col] = df[col].fillna(df[col].mode()[0])

# Numerical columns: Impute with Median (Robust to outliers)
if 'LoanAmount' in df.columns:
    df['LoanAmount'] = df['LoanAmount'].fillna(df['LoanAmount'].median())
if 'Loan_Amount_Term' in df.columns:
    df['Loan_Amount_Term'] = df['Loan_Amount_Term'].fillna(df['Loan_Amount_Term'].mode()[0])

print("\nMissing values after cleaning:", df.isnull().sum().sum())

# 3. EXPLORATORY DATA ANALYSIS (EDA)
plt.figure(figsize=(15, 5))

# Plot 1: Distribution of Loan Amount
plt.subplot(1, 3, 1)
sns.histplot(data=df, x='LoanAmount', kde=True, color='skyblue')
plt.title('Distribution of Loan Amount')
plt.xlabel('Loan Amount')

# Plot 2: Education vs Loan Status
plt.subplot(1, 3, 2)
sns.countplot(data=df, x='Education', hue='Loan_Status', palette='pastel')
plt.title('Education vs Loan Approval/Default')

# Plot 3: Income vs Loan Status
plt.subplot(1, 3, 3)
sns.boxplot(data=df, x='Loan_Status', y='ApplicantIncome', palette='muted')
plt.title('Applicant Income vs Loan Status')

plt.tight_layout()
plt.show()

# 4. DATA PREPROCESSING (Encoding)
# Drop unique identifier if present
if 'Loan_ID' in df.columns:
    df = df.drop(columns=['Loan_ID'])

# Label Encode categorical target and features
le = LabelEncoder()
df['Loan_Status'] = le.fit_transform(df['Loan_Status']) # Y -> 1, N -> 0 (Note: depending on data, default mapping may vary)

# Convert remaining text features into dummy variables
df = pd.get_dummies(df, drop_first=True)

# 5. MODEL TRAINING
X = df.drop(columns=['Loan_Status'])
y = df['Loan_Status']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

model = LogisticRegression(max_iter=1000)
model.fit(X_train, y_train)

# 6. MODEL EVALUATION
# ==========================================
y_pred = model.predict(X_test)

accuracy = accuracy_score(y_test, y_pred)
cm = confusion_matrix(y_test, y_pred)

print("\n================ MODEL METRICS ================")
print(f"Accuracy Score: {accuracy:.2%}")
print("\nClassification Report:\n", classification_report(y_test, y_pred))

# Plot Confusion Matrix
plt.figure(figsize=(5, 4))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
            xticklabels=['Default (N)', 'Approved (Y)'], 
            yticklabels=['Default (N)', 'Approved (Y)'])
plt.title('Confusion Matrix')
plt.xlabel('Predicted Label')
plt.ylabel('True Label')
plt.show()