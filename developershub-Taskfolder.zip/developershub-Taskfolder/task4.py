"""
Task 4: Predicting Insurance Claim Amounts
Dataset: Medical Cost Personal Dataset
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import mean_absolute_error, mean_squared_error

# ─────────────────────────────────────────────
# 1. LOAD DATA
# ─────────────────────────────────────────────
df = pd.read_csv("https://raw.githubusercontent.com/stedy/Machine-Learning-with-R-datasets/master/insurance.csv")
print("Dataset Loaded Successfully")
print(df.head())

# ─────────────────────────────────────────────
# 2. PREPROCESSING
# ─────────────────────────────────────────────
df_encoded = df.copy()
le = LabelEncoder()
df_encoded["sex"]    = le.fit_transform(df["sex"])
df_encoded["smoker"] = le.fit_transform(df["smoker"])
df_encoded["region"] = le.fit_transform(df["region"])

X = df_encoded.drop("charges", axis=1)
y = df_encoded["charges"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# ─────────────────────────────────────────────
# 3. TRAIN MODEL
# ─────────────────────────────────────────────
model = LinearRegression()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

# ─────────────────────────────────────────────
# 4. EVALUATE MODEL
# ─────────────────────────────────────────────
mae  = mean_absolute_error(y_test, y_pred)
rmse = np.sqrt(mean_squared_error(y_test, y_pred))
r2   = model.score(X_test, y_test)

print("\n===== MODEL PERFORMANCE =====")
print(f"MAE  : ${mae:,.2f}")
print(f"RMSE : ${rmse:,.2f}")
print(f"R²   : {r2:.4f}")

# ─────────────────────────────────────────────
# 5. VISUALIZATIONS (Required Only)
# ─────────────────────────────────────────────
fig, axes = plt.subplots(1, 3, figsize=(15, 5))
fig.suptitle("Insurance Charges Analysis", fontsize=14, fontweight="bold")

# Plot 1: BMI vs Charges
axes[0].scatter(df["bmi"], df["charges"], alpha=0.5, color="steelblue", s=20)
axes[0].set_xlabel("BMI")
axes[0].set_ylabel("Charges ($)")
axes[0].set_title("BMI vs Charges")

# Plot 2: Age vs Charges
axes[1].scatter(df["age"], df["charges"], alpha=0.5, color="green", s=20)
axes[1].set_xlabel("Age")
axes[1].set_ylabel("Charges ($)")
axes[1].set_title("Age vs Charges")

# Plot 3: Smoking Status vs Charges
smoker_groups = [df[df["smoker"] == "no"]["charges"], df[df["smoker"] == "yes"]["charges"]]
axes[2].boxplot(smoker_groups, labels=["Non-Smoker", "Smoker"])
axes[2].set_xlabel("Smoking Status")
axes[2].set_ylabel("Charges ($)")
axes[2].set_title("Smoking Status vs Charges")

plt.tight_layout()
plt.savefig("insurance_analysis.png", dpi=150, bbox_inches="tight")
plt.show()
print("\nPlot saved as 'insurance_analysis.png'")