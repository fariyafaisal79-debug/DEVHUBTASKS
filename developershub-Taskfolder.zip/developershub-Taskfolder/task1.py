import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = sns.load_dataset('iris')

print("**Shape of Datasets**")
print(df.shape)  

print("\n**Dataset Columns **")
print(df.columns)  

print("\n**First 5 Rows **")
print(df.head())  
plt.figure(figsize=(10, 6))
# Plotting all 4 variables in one scatter plot using size (sizes) and hue
sns.scatterplot(
    data=df, 
    x='sepal_length', 
    y='sepal_width', 
    hue='petal_width', 
    size='petal_length', 
    sizes=(20, 200), 
    palette='viridis'
)

plt.title('4-Dimensional Analysis via  Scatter Plot')
plt.xlabel('Sepal Length (cm)')
plt.ylabel('Sepal Width (cm)')
plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
plt.tight_layout()
plt.show()
#histogram--
plt.figure(figsize=(8, 5))
sns.histplot(data=df, x='petal_length', hue='species', kde=True, element='step', palette='muted')
plt.title('Distribution of Petal Length by Species')
plt.xlabel('Petal Length (cm)')
plt.ylabel('Count')
plt.show()
#box plot
plt.figure(figsize=(8, 5))
sns.boxplot(data=df, x='species', y='petal_width', palette='pastel')
plt.title('Petal Width Distribution & Outliers by Species')
plt.xlabel('Species')
plt.ylabel('Petal Width (cm)')
plt.show()
