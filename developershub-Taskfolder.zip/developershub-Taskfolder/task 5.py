
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# LOAD DATASET
df = pd.read_csv(r"C:\Users\ACER\Downloads\developershub-Taskfolder\bank-additional-full.csv", sep=";")

print(df['y'].value_counts())  # This should now work
print("=" * 50)
print("DATASET OVERVIEW")
print("=" * 50)
print(f"Shape  : {df.shape}")
print(f"\nFirst 5 rows:\n{df.head()}")
print(f"\nMissing Values:\n{df.isnull().sum()}")
print(f"\nTarget Distribution:\n{df['y'].value_counts()}")

# ─────────────────────────────────────────────
# 2. DATA EXPLORATION & VISUALIZATION
# ─────────────────────────────────────────────
fig, axes = plt.subplots(1, 3, figsize=(15, 5))
fig.suptitle("Customer Data Exploration", fontsize=14, fontweight="bold")

# Plot 1: Age Distribution by Loan Acceptance
yes = df[df["y"] == "yes"]["age"]
no  = df[df["y"] == "no"]["age"]
axes[0].hist(yes, bins=20, alpha=0.6, color="green", label="Accepted")
axes[0].hist(no,  bins=20, alpha=0.6, color="red",   label="Rejected")
axes[0].set_xlabel("Age")
axes[0].set_ylabel("Count")
axes[0].set_title("Age vs Loan Acceptance")
axes[0].legend()

# Plot 2: Job vs Acceptance Rate
job_accept = df.groupby("job")["y"].apply(lambda x: (x == "yes").mean() * 100)
job_accept.sort_values().plot(kind="barh", ax=axes[1], color="steelblue", edgecolor="white")
axes[1].set_xlabel("Acceptance Rate (%)")
axes[1].set_title("Job Type vs Acceptance Rate")

# Plot 3: Marital Status vs Loan Acceptance
marital_counts = df.groupby(["marital", "y"]).size().unstack()
marital_counts.plot(kind="bar", ax=axes[2], color=["red", "green"], edgecolor="white", rot=0)
axes[2].set_xlabel("Marital Status")
axes[2].set_ylabel("Count")
axes[2].set_title("Marital Status vs Loan Acceptance")
axes[2].legend(["Rejected", "Accepted"])

plt.tight_layout()
plt.savefig("loan_exploration.png", dpi=150, bbox_inches="tight")
plt.show()
print("\nExploration plot saved as 'loan_exploration.png'")

# ─────────────────────────────────────────────
# 3. PREPROCESSING
# ─────────────────────────────────────────────
df_encoded = df.copy()

le = LabelEncoder()
cat_cols = df_encoded.select_dtypes(include="object").columns
for col in cat_cols:
    df_encoded[col] = le.fit_transform(df_encoded[col])

X = df_encoded.drop("y", axis=1)
y = df_encoded["y"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

print(f"\nTraining samples : {len(X_train)}")
print(f"Testing  samples : {len(X_test)}")

# ─────────────────────────────────────────────
# 4. TRAIN DECISION TREE MODEL
# ─────────────────────────────────────────────
model = DecisionTreeClassifier(max_depth=5, random_state=42)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

# ─────────────────────────────────────────────
# 5. EVALUATE MODEL
# ─────────────────────────────────────────────
acc = accuracy_score(y_test, y_pred)

print("\n" + "=" * 50)
print("MODEL PERFORMANCE")
print("=" * 50)
print(f"Accuracy : {acc * 100:.2f}%")
print(f"\nClassification Report:\n{classification_report(y_test, y_pred, target_names=['No','Yes'])}")

# Confusion Matrix
cm = confusion_matrix(y_test, y_pred)
fig2, ax = plt.subplots(figsize=(5, 4))
im = ax.imshow(cm, cmap="Blues")
ax.set_xticks([0, 1]); ax.set_yticks([0, 1])
ax.set_xticklabels(["No", "Yes"]); ax.set_yticklabels(["No", "Yes"])
ax.set_xlabel("Predicted"); ax.set_ylabel("Actual")
ax.set_title("Confusion Matrix")
for i in range(2):
    for j in range(2):
        ax.text(j, i, cm[i, j], ha="center", va="center",
                color="white" if cm[i, j] > cm.max()/2 else "black", fontsize=14)
plt.colorbar(im)
plt.tight_layout()
plt.savefig("loan_confusion_matrix.png", dpi=150, bbox_inches="tight")
plt.show()
print("Confusion matrix saved as 'loan_confusion_matrix.png'")

# ─────────────────────────────────────────────
# 6. BUSINESS INSIGHTS
# ─────────────────────────────────────────────
print("\n" + "=" * 50)
print("BUSINESS INSIGHTS")
print("=" * 50)

feat_imp = pd.Series(model.feature_importances_, index=X.columns)
top5 = feat_imp.sort_values(ascending=False).head(5)
print("\nTop 5 Features Influencing Loan Acceptance:")
for feat, score in top5.items():
    print(f"  {feat:<20} : {score:.4f}")

print("\nAcceptance Rate by Job:")
print(df.groupby("job")["y"].apply(lambda x: f"{(x=='yes').mean()*100:.1f}%").to_string())

print("\nAcceptance Rate by Marital Status:")
print(df.groupby("marital")["y"].apply(lambda x: f"{(x=='yes').mean()*100:.1f}%").to_string())