import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

file_path = r"c:/Users/ACER/Downloads/developershub-Taskfolder/Churn_Modelling.csv"

try:
    df = pd.read_csv(file_path)
    print("Successfully read CSV from Downloads path.")
except FileNotFoundError:
    print("Target CSV missing from path. Generating isolated mockup for pipeline consistency.")
    np.random.seed(42)
    n_samples = 1000
    df = pd.DataFrame({
        'CreditScore': np.random.randint(350, 850, n_samples),
        'Geography': np.random.choice(['France', 'Spain', 'Germany'], n_samples),
        'Gender': np.random.choice(['Male', 'Female'], n_samples),
        'Age': np.random.randint(18, 80, n_samples),
        'Tenure': np.random.randint(0, 10, n_samples),
        'Balance': np.random.uniform(0, 200000, n_samples),
        'NumOfProducts': np.random.randint(1, 4, n_samples),
        'HasCrCard': np.random.choice([0, 1], n_samples),
        'IsActiveMember': np.random.choice([0, 1], n_samples),
        'EstimatedSalary': np.random.uniform(10000, 150000, n_samples),
        'Exited': np.random.choice([0, 1], n_samples, p=[0.8, 0.2])
    })

print(f"Data Base Dimensions: {df.shape}")

# 2. DATA CLEANING
drop_cols = ['RowNumber', 'CustomerId', 'Surname']
for col in drop_cols:
    if col in df.columns:
        df = df.drop(columns=[col])

# 3. CATEGORICAL ENCODING
cat_feats = [c for c in ['Geography', 'Gender'] if c in df.columns]
df = pd.get_dummies(df, columns=cat_feats, drop_first=True)

# 4. SPLIT AND FEATURE SCALING
X = df.drop(columns=['Exited'])
y = df['Exited']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# 5. MODEL TRAINING
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train_scaled, y_train)

# 6. PERFORMANCE METRICS
y_pred = model.predict(X_test_scaled)
print("\n================ MODEL PERFORMANCE ================")
print(f"Overall Accuracy: {accuracy_score(y_test, y_pred):.2%}")
print("\nClassification Report:\n", classification_report(y_test, y_pred))

# Confusion Matrix Heatmap
plt.figure(figsize=(5, 4))
sns.heatmap(confusion_matrix(y_test, y_pred), annot=True, fmt='d', cmap='Reds',
            xticklabels=['Stayed (0)', 'Left (1)'], yticklabels=['Stayed (0)', 'Left (1)'])
plt.title('Churn Confusion Matrix')
plt.ylabel('True Label')
plt.xlabel('Predicted Label')
plt.tight_layout()
plt.show()

# 7. FEATURE IMPORTANCE PLOT
importances = model.feature_importances_
feat_names = X.columns
sort_idx = np.argsort(importances)[::-1]

plt.figure(figsize=(10, 5))
# Fix: Mapped feature labels directly to hue to satisfy newer Seaborn specifications
sns.barplot(x=importances[sort_idx], y=feat_names[sort_idx], hue=feat_names[sort_idx], palette='viridis', legend=False)
plt.title('What Drives Bank Churn? (Feature Importance)')
plt.xlabel('Importance Score')
plt.ylabel('Features')
plt.tight_layout()
plt.show()